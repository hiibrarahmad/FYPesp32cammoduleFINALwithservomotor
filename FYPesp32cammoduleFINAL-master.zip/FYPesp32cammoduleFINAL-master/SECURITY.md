# Security Policy

## Supported Versions
project are
currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |


## Reporting a Vulnerability
hope next update will be recieved in a weak
